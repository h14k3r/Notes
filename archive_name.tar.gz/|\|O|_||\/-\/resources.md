# XXE
https://book.hacktricks.xyz/pentesting-web/xxe-xee-xml-external-entity

#### back 
[[xxe]]


#### content
1.  https://www.youtube.com/@7SeasSecurity/videos
2. https://academy.ranakhalil.com/courses/enrolled/1491236


